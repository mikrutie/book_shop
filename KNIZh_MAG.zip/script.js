document.addEventListener('DOMContentLoaded', function() {
    const cartButtons = document.querySelectorAll('.add-to-cart');
    
    cartButtons.forEach(button => {
        button.addEventListener('click', function(event) {
            event.stopPropagation();
            const id = this.getAttribute('data-id');
            const title = this.getAttribute('data-title');
            const price = parseInt(this.getAttribute('data-price'));
            const img = this.getAttribute('data-img');
            
            if (typeof addToCart === 'function') {
                addToCart({ id, title, price, img });
            } else {
                console.error('cart.js не загружен');
            }
        });
    });
});