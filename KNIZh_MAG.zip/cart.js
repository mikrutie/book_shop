const CART_KEY = 'bookstore_cart';

function getCart() {
    const cart = localStorage.getItem(CART_KEY);
    return cart ? JSON.parse(cart) : [];
}

function saveCart(cart) {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
}

function addToCart(book) {
    let cart = getCart();
    const existing = cart.find(item => item.id === book.id);
    if (existing) {
        existing.quantity += 1;
    } else {
        cart.push({
            id: book.id,
            title: book.title,
            price: book.price,
            img: book.img,
            quantity: 1
        });
    }
    saveCart(cart);
    updateCartCount(); 
    alert(`📚 "${book.title}" добавлена в корзину!`);
}

function removeFromCart(bookId) {
    let cart = getCart();
    const index = cart.findIndex(item => item.id === bookId);
    if (index !== -1) {
        if (cart[index].quantity > 1) {
            cart[index].quantity -= 1;
        } else {
            cart.splice(index, 1);
        }
        saveCart(cart);
        updateCartCount();
        if (window.location.pathname.includes('cart.html')) {
            renderCartPage();
        }
    }
}

function clearCart() {
    saveCart([]);
    updateCartCount();
    if (window.location.pathname.includes('cart.html')) {
        renderCartPage();
    }
}

function updateCartCount() {
    const cart = getCart();
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    const counterSpan = document.getElementById('cart-count');
    if (counterSpan) {
        counterSpan.textContent = totalItems;
        if (totalItems > 0) {
            counterSpan.style.display = 'inline-block';
        } else {
            counterSpan.style.display = 'none';
        }
    }
}

function renderCartPage() {
    const cart = getCart();
    const cartItemsContainer = document.getElementById('cart-items');
    const cartTotalSpan = document.getElementById('cart-total');
    if (!cartItemsContainer) return;

    if (cart.length === 0) {
        cartItemsContainer.innerHTML = '<tr><td colspan="4" style="text-align:center;">Корзина пуста. Перейдите в <a href="index.html">каталог</a></td></tr>';
        if (cartTotalSpan) cartTotalSpan.textContent = '0 ₽';
        return;
    }

    let total = 0;
    let html = '';
    for (let item of cart) {
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        html += `
            <tr>
                <td class="cart-img-cell"><img src="${item.img}" alt="${item.title}" width="60"></td>
                <td>${item.title}</td>
                <td>${item.price} ₽</td>
                <td>
                    <button class="cart-quantity-btn" data-id="${item.id}" data-action="decr">−</button>
                    <span class="cart-quantity">${item.quantity}</span>
                    <button class="cart-quantity-btn" data-id="${item.id}" data-action="incr">+</button>
                    <button class="cart-remove-btn" data-id="${item.id}">🗑 Удалить</button>
                </td>
                <td>${itemTotal} ₽</td>
            </tr>
        `;
    }
    cartItemsContainer.innerHTML = html;
    if (cartTotalSpan) cartTotalSpan.textContent = total + ' ₽';

    document.querySelectorAll('.cart-quantity-btn[data-action="incr"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            const book = cart.find(item => item.id === id);
            if (book) {
                addToCart({ id: book.id, title: book.title, price: book.price, img: book.img });
                renderCartPage(); 
            }
        });
    });
    document.querySelectorAll('.cart-quantity-btn[data-action="decr"]').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            removeFromCart(id);
            renderCartPage();
        });
    });
    document.querySelectorAll('.cart-remove-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const id = btn.getAttribute('data-id');
            let cart = getCart();
            cart = cart.filter(item => item.id !== id);
            saveCart(cart);
            updateCartCount();
            renderCartPage();
        });
    });
}

document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
});